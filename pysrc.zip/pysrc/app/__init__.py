"""
English Speaking Practice Application

AI-powered English speaking practice with pronunciation and content assessment
using Azure Speech Services and OpenAI.
"""

__version__ = "1.0.0"